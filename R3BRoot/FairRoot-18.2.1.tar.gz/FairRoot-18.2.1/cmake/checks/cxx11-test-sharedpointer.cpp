#include <memory>
using std::shared_ptr;

int main()
{
    
    return 0;
}
