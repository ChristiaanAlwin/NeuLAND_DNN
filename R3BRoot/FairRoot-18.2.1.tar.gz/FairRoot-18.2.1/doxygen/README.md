
### Generating Doxygen documentation

If the flage -DBUILD_DOXYGEN=ON  is set when calling cmake, the doxygen documentation will be generated when calling make.  The generated html files can then be found in "build/doxygen/doc/html"

Doxygen documantation is also available online [here](http://Fairrootgroup.github.io/FairRoot/) 
