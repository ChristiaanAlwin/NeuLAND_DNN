# Tutorial 3 - Message Queue part

This part of Tutorial3 demonstrates how to transport data of Tutorial3 (FairTestDetector) via FairMQ.
