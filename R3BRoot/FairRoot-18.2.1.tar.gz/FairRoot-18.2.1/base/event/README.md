event
========

Base data classes of FairRoot, for event headers, Monte Carlo points, hits, radiation length measurements.
