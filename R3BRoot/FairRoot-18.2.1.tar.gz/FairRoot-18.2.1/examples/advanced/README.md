# Advanced examples

## Tutorial3

Detector simulation and digitization event wise and timebased simulation.
Use of FairMQ


## MbsTutorial

Shows how to use MBS data unpacking with FairRunOnline steering class. FairTut8Unpack implement parsing of MBS subevents and
creates output in form of array of FairTut8RawItem data objects.

## GoTutorial

Shows how one can use devices written in the [Go](https://golang.org)
programming language and integrate them into a `C++` base device topology.
