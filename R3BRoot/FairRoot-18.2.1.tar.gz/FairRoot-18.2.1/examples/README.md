# Examples

## MQ

Set of simple FairMQ examples.

## Simulation

Set of simulation examples

## Advanced

Reconstruction examples, use of parameters, detector simulation and digitization event wise and timebased simulation, etc.
