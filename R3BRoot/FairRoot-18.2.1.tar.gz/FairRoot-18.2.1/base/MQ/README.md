Message Queue
========

Contains the classes that provide connection between the Message Queue data transport layer (located in `FairRoot/fairmq/`) and the ROOT classes.